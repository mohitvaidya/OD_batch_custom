Notes
======================================

.. toctree::
   :maxdepth: 2

   benchmarks
   compatibility
   contributing
   changelog
